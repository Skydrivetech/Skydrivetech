
document.addEventListener('DOMContentLoaded', () => {
    console.log('SkyDrive Tech Innovations Website Loaded');
});
